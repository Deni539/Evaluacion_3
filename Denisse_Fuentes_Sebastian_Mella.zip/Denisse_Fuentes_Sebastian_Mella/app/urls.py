from django.urls import path
from .views import index, Noticias, Nosotros, Formulario, Api, Editor,agregarrec,actualizarrec, ingreso

urlpatterns = [
    path('', index, name='index'),
    path('Noticias.html/', Noticias, name='Noticias'),
    path('Nosotros.html/', Nosotros, name='Nosotros'),
    path('Formulario.html/', Formulario, name='Formulario'),
    path('Api.html/', Api, name='Api'),
    path('Editor.html/', Editor, name='Editor'),
    path('agregarrec/',agregarrec,name='agregarrec'),
    path('actualizarrec/<int:rut>/',actualizarrec,name='actualizarrec'),
    path('ingreso.html/', ingreso, name='ingreso'),
    path('Noticias.html/Nosotros.html/', Nosotros, name='Nosotros'),
]
