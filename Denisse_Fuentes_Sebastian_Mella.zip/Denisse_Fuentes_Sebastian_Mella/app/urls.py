from django.urls import path
from .views import index, Noticias

urlpatterns = [
    path('', index, name='index'),
    path('Noticias/', Noticias, name='Noticias'),
]
