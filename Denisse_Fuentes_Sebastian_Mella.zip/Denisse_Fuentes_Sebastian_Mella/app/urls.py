from django.urls import path
from .views import index, Noticias, Nosotros, Formulario, Api

urlpatterns = [
    path('', index, name='index'),
    path('Noticias/', Noticias, name='Noticias'),
    path('Nosotros/', Nosotros, name='Nosotros'),
    path('Formulario/', Formulario, name='Formulario'),
    path('Api/', Api, name='Api'),
]
