from django.contrib import admin
from .models import Editor

# Register your models here.

class EditorAdmin(admin.ModelAdmin):
    list_display="rut","nombre","apellido_paterno","apellido_materno","fecha_nacimiento","id_genero","telefono", "email","direccion","activo"

admin.site.register(Editor,EditorAdmin)