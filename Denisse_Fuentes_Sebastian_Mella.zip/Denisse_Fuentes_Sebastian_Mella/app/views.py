from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'app/index.html')

def Noticias(request):
    return render(request, 'app/Noticias.html')

def Nosotros(request):
    return render(request, 'app/Nosotros.html')

def Formulario(request):
    return render(request, 'app/Formulario.html')

def Api(request):
    return render(request, 'app/Api.html')