from django.shortcuts import redirect, render
from .models import Alumno


# Create your views here.
def inicio (request) :
    return render(request, 'app/inicio.html')

def noticias (request) :
    return render(request, 'app/noticias.html')

def nosotros (request) :
    return render(request, 'app/nosotros.html')

def formulario (request) :
    return render(request, 'app/formulario.html')

def api (request) :
    return render(request, 'app/api.html')



# Create your views here.
def crud(request):
    alu=Alumno.objects.all()
    return render(request, 'app/crud.html',{'alu':alu})

def agregar(request):
    return render(request, 'app/agregar.html')

def agregarrec(request):
    x=request.POST['nombre']
    y=request.POST['apellido']
    z=request.POST['comuna']
    alu=Alumno(nombre=x,apellido=y,comuna=z)
    alu.save()
    return redirect("/")

def eliminar(request,id):
    alu=Alumno.objects.get(id=id)
    alu.delete()
    return redirect("/")

def actualizar(request,id):
    alu=Alumno.objects.get(id=id)
    return render(request,'app/actualizar.html',{'alu':alu})

def actualizarrec(request,id):
    x=request.POST['nombre']
    y=request.POST['apellido']
    z=request.POST['comuna']
    alu=Alumno.objects.get(id=id)
    alu.nombre=x
    alu.apellido=y
    alu.comuna=z
    alu.save()
    return redirect("/")