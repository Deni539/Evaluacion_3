from django.shortcuts import redirect, render
from .models import Editor


# Create your views here.
def inicio (request) :
    return render(request, 'app/inicio.html')

def noticias (request) :
    return render(request, 'app/noticias.html')

def nosotros (request) :
    return render(request, 'app/nosotros.html')

def formulario (request) :
    return render(request, 'app/formulario.html')

def api (request) :
    return render(request, 'app/api.html')



# Create your views here.
def crud(request):
    edi=Editor.objects.all()
    return render(request, 'app/crud.html',{'edi':edi})

def agregar(request):
    return render(request, 'app/agregar.html')

def agregarrec(request):
    rut=request.POST['rut']
    nombre=request.POST['nombre']
    apellido_paterno=request.POST['apellido_paterno']
    apellido_materno=request.POST['apellido_materno']
    fecha_nacimiento=request.POST['fecha_nacimiento']
    id_genero =request.POST['id_genero']
    telefono=request.POST['telefono']
    email=request.POST['email']
    direccion=request.POST['direccion']
    activo='1'
    edi.save()
    return redirect("/crud")

def eliminar(request,id):
    edi=Editor.objects.get(id=rut)
    edi.delete()
    return redirect("/crud")

def actualizar(request,id):
    alu=Alumno.objects.get(id=rut)
    return render(request,'app/actualizar.html',{'edi':edi})

def actualizarrec(request,id):
    rut=request.POST['rut']
    nombre=request.POST['nombre']
    apellido_paterno=request.POST['apellido_paterno']
    apellido_materno=request.POST['apellido_materno']
    fecha_nacimiento=request.POST['fecha_nacimiento']
    id_genero =request.POST['id_genero']
    telefono=request.POST['telefono']
    email=request.POST['email']
    direccion=request.POST['direccion']
    activo='1'
    edi=Editor.objects.get(id=rut)

    edi.save()
    return redirect("/crud")