from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'app/index.html')

def Noticias(request):
    return render(request, 'app/Noticias.html')

def Nosotros(request):
    return render(request, 'app/Nosotros.html')

def Formulario(request):
    return render(request, 'app/Formulario.html')

def Api(request):
    return render(request, 'app/Api.html')

def Editor(request):
    return render(request, 'app/Editor.html')

def agregarrec(request):
    rut=request.POST['rut']
    nombre=request.POST['nombre']
    apellido_paterno=request.POST['apellido_paterno']
    apellido_materno=request.POST['apellido_materno']
    fecha_nacimiento=request.POST['fecha_nacimiento']
    id_genero =request.POST['id_genero']
    telefono=request.POST['telefono']
    email=request.POST['email']
    direccion=request.POST['direccion']
    activo='1'
    edi.save()
    return redirect("/")

def actualizarrec(request,id):
    rut=request.POST['rut']
    nombre=request.POST['nombre']
    apellido_paterno=request.POST['apellido_paterno']
    apellido_materno=request.POST['apellido_materno']
    fecha_nacimiento=request.POST['fecha_nacimiento']
    id_genero =request.POST['id_genero']
    telefono=request.POST['telefono']
    email=request.POST['email']
    direccion=request.POST['direccion']
    activo='1'
    edi=Editor.objects.get(id=rut)

    edi.save()
    return redirect("/")
   