from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from .forms import CustomUserCreationForm
from django.contrib.auth import authenticate, login

# Create your views here.
def index(request):
    return render(request, 'app/index.html')

def Noticias(request):
    return render(request, 'app/Noticias.html')

def Nosotros(request):
    return render(request, 'app/Nosotros.html')

def Formulario(request):
    return render(request, 'app/Formulario.html')

def Api(request):
    return render(request, 'app/Api.html')

def Editor(request):
    return render(request, 'app/Editor.html')

def agregarrec(request):
    rut=request.POST['rut']
    nombre=request.POST['nombre']
    apellido_paterno=request.POST['apellido_paterno']
    apellido_materno=request.POST['apellido_materno']
    fecha_nacimiento=request.POST['fecha_nacimiento']
    id_genero =request.POST['id_genero']
    telefono=request.POST['telefono']
    email=request.POST['email']
    direccion=request.POST['direccion']
    activo='1'
    edi.save()
    return redirect("/")

def actualizarrec(request,id):
    rut=request.POST['rut']
    nombre=request.POST['nombre']
    apellido_paterno=request.POST['apellido_paterno']
    apellido_materno=request.POST['apellido_materno']
    fecha_nacimiento=request.POST['fecha_nacimiento']
    id_genero =request.POST['id_genero']
    telefono=request.POST['telefono']
    email=request.POST['email']
    direccion=request.POST['direccion']
    activo='1'
    edi=Editor.objects.get(id=rut)

    edi.save()
    return redirect("/")

def ingreso(request):
    data = {
        'form': CustomUserCreationForm()
    }
    if request.method == 'POST':
        user_creation_form = CustomUserCreationForm(data=request.POST)
        if user_creation_form.is_valid():
            user_creation_form.save()
            user = authenticate(username=user_creation_form.cleaned_data['username'], password=user_creation_form.cleaned_data['password1'])
            login(request,user)
    return render(request, 'ingreso.html',data)