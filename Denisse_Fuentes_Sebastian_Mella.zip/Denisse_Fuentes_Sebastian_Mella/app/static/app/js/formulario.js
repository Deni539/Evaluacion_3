var nombre = document.getElementById('nombre');
var apellido1 = document.getElementById('apellidop');
var apellido2 = document.getElementById('apellidom');
var rb1 = document.getElementById('otro');
var rb2 = document.getElementById('masculino');
var rb3 = document.getElementById('femenino');
var direccion = document.getElementById('direccion'); 
var correo = document.getElementById('correo');
var celu = document.getElementById('telefono'); 

var error = document.getElementById('error');

error.style.color= "#ee5555"

function enviarformulario(){
    console.log("Enviando formulario");
    var mensajeserror =[];

    if(nombre.value === null || nombre.value === ""){
        mensajeserror.push("Ingresa nombre");
    }
    if(apellido1.value === null || apellido1.value === ""){
        mensajeserror.push("Ingresa apellido Paterno");
    }
    if(apellido2.value === null || apellido2.value === ""){
        mensajeserror.push("Ingresa apellido Materno");
    }


    if(rb1.checked==true){
    }
    else if(rb2.checked==true){
    }
    else if(rb3.checked==true){
    }
    else mensajeserror.push("Selecciona un Genero")
    
    if(direccion.value === null || direccion.value === ""){
      mensajeserror.push("Ingresa Direccion");
    }

    if(correo.value === null || correo.value === ""){
      mensajeserror.push("Ingresa Correo");
    }
    

    error.innerHTML = mensajeserror.join(" , ")
    return false;
}



// oír los cambios en la caja de texto e ir dando formato al RUT
document.addEventListener('input', (e) => {
    var rut = document.getElementById('rut');
  
    if (e.target === rut) {
      let rutFormateado = darFormatoRUT(rut.value);
      rut.value = rutFormateado;
    }
  });
  
  // dar formato XX.XXX.XXX-X
  function darFormatoRUT(rut) {
    // dejar solo números y letras 'k'
    var rutLimpio = rut.replace(/[^0-9kK]/g, '');
  
    // asilar el cuerpo del dígito verificador
    var cuerpo = rutLimpio.slice(0, -1);
    var dv = rutLimpio.slice(-1).toUpperCase();
  
    if (rutLimpio.length < 2) return rutLimpio;
  
    // colocar los separadores de miles al cuerpo
    let cuerpoFormatoMiles = cuerpo
      .toString()
      .split('')
      .reverse()
      .join('')
      .replace(/(?=\d*\.?)(\d{3})/g, '$1.');
  
    cuerpoFormatoMiles = cuerpoFormatoMiles
      .split('')
      .reverse()
      .join('')
      .replace(/^[\.]/, '');
  
    return `${cuerpoFormatoMiles}-${dv}`;
  }
  
  // si presiona ENTER ejecutar la validación
  document.addEventListener('keypress', (e) => {
    if (e.keyCode == 13) ejecutarValidacion();
  });
  
  // oír el clic y si presiona el botón 'Validar RUT' ejecutar la validación
  document.addEventListener('click', (e) => {
    var botonValidarRUT = document.getElementById('btn-valida-rut');
  
    if (e.target === botonValidarRUT) {
      ejecutarValidacion();
    }
  });
  
  function ejecutarValidacion() {
    var rut = document.getElementById('rut').value;
    var resultado = validarRUT(rut);
    var salida = document.querySelector('.salida');
  
    if (!rut) {
      salida.innerHTML = `<p style="color: #ee5555;">Debes ingresar un RUT</p>`;
    } else if (resultado === true) {
      salida.innerHTML = `<p style="color: darkgreen;">El RUT ${rut} es válido</p>`;
    } else {
      salida.innerHTML = `<p style="color: red;">El RUT ${rut} no es válido</p>`;
    }
  
    document.getElementById('rut').value = '';
  }
  
  function validarRUT(rut) {
    // dejar solo números y letras 'k'
    var rutLimpio = rut.replace(/[^0-9kK]/g, '');
  
    // verificar que ingrese al menos 2 caracteres válidos
    if (rutLimpio.length < 2) return false;
  
    // asilar el cuerpo del dígito verificador
    var cuerpo = rutLimpio.slice(0, -1);
    var dv = rutLimpio.slice(-1).toUpperCase();
  
    // validar que el cuerpo sea numérico
    if (!cuerpo.replace(/[^0-9]/g, '')) return false;
  
    // calcular el DV asociado al cuerpo del RUT
    var dvCalculado = calcularDV(cuerpo);
  
    // comparar el DV del RUT recibido con el DV calculado
    return dvCalculado == dv;
  }
  
  function calcularDV(cuerpoRUT) {
    let suma = 1;
    let multiplo = 0;
  
    for (; cuerpoRUT; cuerpoRUT = Math.floor(cuerpoRUT / 10))
      suma = (suma + (cuerpoRUT % 10) * (9 - (multiplo++ % 6))) % 11;
  
    return suma ? suma - 1 : 'K';
  }