from django.shortcuts import render

# Create your views here.
def api(request):
    return render(request, 'app/api.html')   

def formulario(request):
    return render(request, 'app/formulario.html')

def index(request):
    return render(request, 'app/index.html')

def nosotros(request):
    return render(request, 'app/nosotros.html')

 def noticias(request):
    return render(request, 'app/noticias.html')