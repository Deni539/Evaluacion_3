from django.urls import path
from .views import api, formulario, index, nosotros, noticias

urlpatterns = {
path('api/',api, name='api'),
path('formulario/',formulario, name='formulario'),
path('',index, name='index'),
path('nosotros/',nosotros, name='nosotros'),
path('noticias/',noticias, name='noticias'),

}